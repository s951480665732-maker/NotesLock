package com.example.noteslock;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.content.res.ColorStateList;
import android.graphics.Insets;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    private static final int MIN_PASSWORD = 4;
    private static final int REQUEST_ADMIN = 1;

    private static final class Note {
        String title = "";
        String body = "";

        boolean isBlank() {
            return title.trim().isEmpty() && body.trim().isEmpty();
        }
    }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private Store store;
    private FrameLayout root;
    private Look look;
    private PhoneLock phoneLock;
    private Context ui; // контекст со светлой или тёмной темой

    // Всё это очищается при блокировке
    private Store.Session session;
    private List<Note> notes;
    private Note editing;
    private EditText titleField;
    private EditText bodyField;
    private AlertDialog dialog;
    private MediaPlayer errorSound;
    private boolean inSettings;

    private int generation; // растёт при каждой блокировке
    private boolean busy;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(null); // старое состояние экрана не восстанавливаем
        // Запрет скриншотов, записи экрана и превью в списке недавних
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);

        store = new Store(this);
        look = new Look(this);
        phoneLock = new PhoneLock(this);
        setVolumeControlStream(AudioManager.STREAM_MUSIC); // кнопки громкости регулируют звук ошибки
        root = new FrameLayout(this);
        root.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        root.setOnApplyWindowInsetsListener((view, insets) -> {
            applyInsets(view, insets);
            return insets;
        });
        setContentView(root);
        applyLook();
        showStart();
    }

    @SuppressWarnings("deprecation")
    private void applyInsets(View view, WindowInsets insets) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Insets i = insets.getInsets(
                    WindowInsets.Type.systemBars() | WindowInsets.Type.ime());
            view.setPadding(i.left, i.top, i.right, i.bottom);
        } else {
            view.setPadding(insets.getSystemWindowInsetLeft(),
                    insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(),
                    insets.getSystemWindowInsetBottom());
        }
    }

    @Override
    protected void onPause() {
        persist();
        super.onPause();
    }

    /** Вышел из приложения или погас экран: сразу блокируем. */
    @Override
    protected void onStop() {
        lock();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        stopErrorSound();
        executor.shutdown();
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (editing != null) {
            closeEditor();
        } else if (inSettings) {
            showList();
        } else if (session != null) {
            lock();
        } else {
            super.onBackPressed();
        }
    }

    private void lock() {
        generation++;
        busy = false;
        if (dialog != null) {
            dialog.dismiss();
            dialog = null;
        }
        session = null;
        notes = null;
        editing = null;
        titleField = null;
        bodyField = null;
        inSettings = false;
        showStart();
    }

    private void showStart() {
        if (store.exists(0)) showLogin();
        else showSetup();
    }

    // ---------- Первый запуск ----------

    private void showSetup() {
        LinearLayout page = column();
        page.addView(heading("Создайте пароли"));
        page.addView(label("Каждый пароль открывает свои отдельные заметки. "
                + "Минимум " + MIN_PASSWORD + " символа."));
        EditText first = passwordField("Пароль 1");
        EditText firstRepeat = passwordField("Повторите пароль 1");
        EditText second = passwordField("Пароль 2 (можно добавить позже)");
        EditText secondRepeat = passwordField("Повторите пароль 2");
        page.addView(first);
        page.addView(firstRepeat);
        page.addView(second);
        page.addView(secondRepeat);
        page.addView(button("Сохранить", v -> {
            String p1 = text(first);
            String p2 = text(second);
            boolean useSecond = !p2.isEmpty() || !text(secondRepeat).isEmpty();
            if (!validNewPassword(p1, text(firstRepeat))) return;
            if (useSecond && !validNewPassword(p2, text(secondRepeat))) return;
            if (useSecond && p1.equals(p2)) {
                showError("Пароли 1 и 2 должны быть разными");
                return;
            }
            background(() -> useSecond
                    ? new Store.Session[]{store.create(0, p1), store.create(1, p2)}
                    : new Store.Session[]{store.create(0, p1)},
                    created -> {
                        try {
                            if (!store.save(created)) {
                                showError("Не удалось сохранить");
                                return;
                            }
                            showLogin();
                        } catch (Exception e) {
                            showError("Не удалось сохранить");
                        }
                    });
        }));
        show(scroll(page));
    }

    // ---------- Экран блокировки ----------

    private void showLogin() {
        LinearLayout page = column();
        page.addView(heading("🔒 Нотатки"));
        EditText password = passwordField("Пароль");
        page.addView(password);
        Button enter = button("Войти", v -> {
            String entered = text(password);
            if (entered.isEmpty()) return;
            background(() -> store.open(entered), opened -> {
                if (opened == null) {
                    password.setText("");
                    wrongPassword();
                    return;
                }
                phoneLock.passwordCorrect();
                try {
                    notes = parse(opened.json);
                    session = opened;
                    showList();
                } catch (JSONException e) {
                    showError("Не удалось прочитать заметки");
                }
            });
        });
        page.addView(enter);
        password.setImeOptions(EditorInfo.IME_ACTION_DONE
                | EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        password.setOnEditorActionListener((v, action, event) -> {
            if (action != EditorInfo.IME_ACTION_DONE) return false;
            enter.performClick();
            return true;
        });
        page.addView(button("Забыл пароль", v -> confirmReset()));
        show(scroll(page));
    }

    private void playErrorSound() {
        stopErrorSound(); // при новой ошибке звук начинается сначала
        errorSound = MediaPlayer.create(this, R.raw.error_sound);
        if (errorSound == null) return;
        errorSound.setOnCompletionListener(player -> stopErrorSound());
        errorSound.start();
    }

    private void stopErrorSound() {
        if (errorSound != null) {
            errorSound.release();
            errorSound = null;
        }
    }

    private void wrongPassword() {
        if (!phoneLock.enabled()) {
            showError("Неверный пароль");
            return;
        }
        int left = phoneLock.passwordWrong();
        if (left > 0) showError("Неверный пароль. Осталось попыток: " + left);
        else playErrorSound(); // 3-я ошибка: телефон блокируется, звук доигрывает
    }

    private void confirmReset() {
        presentDialog(new AlertDialog.Builder(ui)
                .setTitle("Внимание!")
                .setMessage("Все данные сотрутся: оба пароля и все заметки. "
                        + "Восстановить их будет невозможно. Продолжить?")
                .setPositiveButton("ОК", (d, which) -> {
                    if (store.wipe()) {
                        look.reset();
                        phoneLock.disable();
                        applyLook();
                        lock(); // данных нет, откроется создание новых паролей
                        toast("Данные стёрты. Создайте новый пароль");
                    } else {
                        showError("Не удалось стереть данные");
                    }
                })
                .setNegativeButton("Отмена", null)
                .create());
    }

    // ---------- Список заметок ----------

    private void showList() {
        inSettings = false;
        LinearLayout page = column();
        page.addView(heading("Заметки · пароль " + (session.slot + 1)));
        page.addView(button("+ Новая заметка", v -> {
            if (busy) return;
            Note note = new Note();
            notes.add(0, note);
            showEditor(note);
        }));
        page.addView(button("⚙ Настройки", v -> showSettings()));
        page.addView(button("Заблокировать", v -> lock()));

        if (notes.isEmpty()) page.addView(label("Пока нет заметок"));
        for (Note note : notes) {
            page.addView(noteItem(note));
        }
        show(scroll(page));
    }

    private Button noteItem(Note note) {
        String title = shorten(note.title);
        String body = shorten(note.body);
        String name = title.isEmpty() ? "Без названия" : title;
        if (look.preview() && !body.isEmpty()) name += "\n" + body;
        Button item = button(name, v -> {
            if (!busy) showEditor(note);
        });
        item.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        item.setMaxLines(2);
        item.setEllipsize(TextUtils.TruncateAt.END);
        item.setBackgroundTintList(ColorStateList.valueOf(look.card()));
        item.setTextColor(look.textColor());
        return item;
    }

    private static String shorten(String value) {
        String line = value.trim().replace('\n', ' ');
        return line.length() > 30 ? line.substring(0, 30) + "…" : line;
    }

    // ---------- Настройки ----------

    private void showSettings() {
        inSettings = true;
        LinearLayout page = column();
        page.addView(button("← Назад", v -> showList()));
        page.addView(heading("Настройки"));

        page.addView(label("Оформление"));
        page.addView(button("Тема: " + Look.THEME_NAMES[look.theme()],
                v -> choose("Тема", Look.THEME_NAMES, look.theme(),
                        i -> changeLook(Look.THEME, i))));
        page.addView(button("Цвет: " + Look.ACCENT_NAMES[look.accentIndex()],
                v -> choose("Цвет", Look.ACCENT_NAMES, look.accentIndex(),
                        i -> changeLook(Look.ACCENT, i))));
        page.addView(button("Размер текста: " + Look.SIZE_NAMES[look.sizeIndex()],
                v -> choose("Размер текста", Look.SIZE_NAMES, look.sizeIndex(),
                        i -> changeLook(Look.SIZE, i))));
        page.addView(button("Начало текста в списке: " + (look.preview() ? "Да" : "Нет"),
                v -> changeLook(Look.PREVIEW, look.preview() ? 0 : 1)));
        page.addView(button("Сбросить оформление", v -> {
            look.reset();
            applyLook();
            showSettings();
        }));

        page.addView(label("Безопасность"));
        page.addView(button("Блок телефона после " + PhoneLock.MAX_FAILS + " ошибок: "
                + (phoneLock.enabled() ? "Вкл" : "Выкл"), v -> togglePhoneLock()));
        page.addView(button("Настройки приложения в телефоне", v -> openAppSettings()));

        page.addView(label("Пароли"));
        page.addView(button("Сменить этот пароль",
                v -> passwordDialog(session.slot)));
        int other = 1 - session.slot;
        if (!store.exists(other)) {
            page.addView(button("Добавить пароль " + (other + 1),
                    v -> passwordDialog(other)));
        }
        show(scroll(page));
    }

    private void togglePhoneLock() {
        if (phoneLock.enabled()) {
            phoneLock.disable();
            toast("Блок телефона выключен, разрешение убрано");
            showSettings();
            return;
        }
        if (phoneLock.hasPermission()) {
            phoneLock.setWanted(true);
            showSettings();
            return;
        }
        presentDialog(new AlertDialog.Builder(ui)
                .setTitle("Нужно разрешение")
                .setMessage("После " + PhoneLock.MAX_FAILS + " неверных паролей подряд "
                        + "экран телефона заблокируется, как от кнопки питания. "
                        + "Открывается он обычным способом вашего телефона.\n\n"
                        + "Сейчас откроется системное окно: нажмите там «Активировать». "
                        + "Заметки при этом заблокируются, потом войдите снова.\n\n"
                        + "Перед удалением приложения выключите эту функцию.")
                .setPositiveButton("Разрешить", (d, which) -> requestPermission())
                .setNegativeButton("Отмена", null)
                .create());
    }

    private void requestPermission() {
        phoneLock.setWanted(true); // заработает, только если разрешение дадут
        try {
            startActivityForResult(phoneLock.permissionRequest(), REQUEST_ADMIN);
        } catch (Exception e) {
            phoneLock.setWanted(false);
            showError("Не удалось открыть окно разрешения");
        }
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != REQUEST_ADMIN) return;
        if (phoneLock.hasPermission()) {
            toast("Блок телефона включён");
        } else {
            phoneLock.setWanted(false);
            showError("Разрешение не выдано, блок телефона выключен");
        }
        if (session != null) showSettings();
    }

    private void openAppSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", getPackageName(), null)));
        } catch (Exception e) {
            showError("Не удалось открыть настройки телефона");
        }
    }

    private void choose(String title, String[] names, int selected, IntConsumer picked) {
        presentDialog(new AlertDialog.Builder(ui)
                .setTitle(title)
                .setSingleChoiceItems(names, selected, (d, which) -> {
                    d.dismiss();
                    picked.accept(which);
                })
                .setNegativeButton("Отмена", null)
                .create());
    }

    private void changeLook(String name, int value) {
        look.set(name, value);
        applyLook();
        showSettings();
    }

    /** Меняет тему и цвета без перезапуска экрана (перезапуск заблокировал бы приложение). */
    @SuppressWarnings("deprecation")
    private void applyLook() {
        ui = new ContextThemeWrapper(this,
                look.dark() ? R.style.AppThemeDark : R.style.AppTheme);
        int color = look.background();
        root.setBackgroundColor(color);
        getWindow().setStatusBarColor(color);
        getWindow().setNavigationBarColor(color);
        // Тёмные значки системных панелей на светлом фоне и наоборот
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController bars = getWindow().getInsetsController();
            if (bars != null) {
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                bars.setSystemBarsAppearance(look.dark() ? 0 : mask, mask);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(look.dark() ? 0
                    : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    // ---------- Редактор ----------

    private void showEditor(Note note) {
        editing = note;
        LinearLayout page = column();

        titleField = field("Заголовок", InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        titleField.setText(note.title);

        bodyField = field("Текст заметки", InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        bodyField.setText(note.body);
        bodyField.setGravity(Gravity.TOP | Gravity.START);

        page.addView(button("← Сохранить и назад", v -> closeEditor()));
        page.addView(button("Удалить", v -> presentDialog(new AlertDialog.Builder(ui)
                .setMessage("Удалить заметку?")
                .setPositiveButton("Удалить", (d, which) -> {
                    notes.remove(note);
                    editing = null;
                    persist();
                    showList();
                })
                .setNegativeButton("Отмена", null)
                .create())));
        page.addView(titleField);
        page.addView(bodyField, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        show(page);
    }

    private void closeEditor() {
        readEditor();
        if (editing.isBlank()) notes.remove(editing);
        editing = null;
        persist();
        showList();
    }

    private void readEditor() {
        if (editing == null) return;
        editing.title = text(titleField);
        editing.body = text(bodyField);
    }

    // ---------- Сохранение ----------

    private void persist() {
        if (session == null) return;
        readEditor();
        try {
            Store.Session updated = new Store.Session(
                    session.slot, session.salt, session.key, toJson());
            if (!store.save(updated)) showError("Не удалось сохранить");
        } catch (Exception e) {
            showError("Не удалось сохранить");
        }
    }

    private String toJson() throws JSONException {
        JSONArray array = new JSONArray();
        for (Note note : notes) {
            if (note.isBlank()) continue;
            array.put(new JSONObject().put("title", note.title).put("body", note.body));
        }
        return array.toString();
    }

    private static List<Note> parse(String json) throws JSONException {
        JSONArray array = new JSONArray(json);
        List<Note> result = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject item = array.getJSONObject(i);
            Note note = new Note();
            note.title = item.getString("title");
            note.body = item.getString("body");
            result.add(note);
        }
        return result;
    }

    // ---------- Смена и добавление пароля ----------

    private void passwordDialog(int slot) {
        if (busy) return;
        boolean changing = slot == session.slot;
        LinearLayout box = column();
        EditText password = passwordField("Новый пароль");
        EditText repeat = passwordField("Повторите пароль");
        box.addView(password);
        box.addView(repeat);

        AlertDialog d = new AlertDialog.Builder(ui)
                .setTitle(changing ? "Сменить пароль" : "Пароль " + (slot + 1))
                .setView(box)
                .setPositiveButton("Сохранить", null)
                .setNegativeButton("Отмена", null)
                .create();
        presentDialog(d);
        // Свой обработчик, чтобы окно не закрывалось при ошибке ввода
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String entered = text(password);
            if (!validNewPassword(entered, text(repeat))) return;
            d.dismiss();
            int current = session.slot;
            background(() -> {
                // Пароли двух хранилищ не должны совпадать
                int compareWith = 1 - slot;
                if (store.openSlot(compareWith, entered) != null) return null;
                return store.create(slot, entered);
            }, created -> {
                if (created == null) {
                    showError("Этот пароль использовать нельзя, выберите другой");
                    return;
                }
                try {
                    if (slot == current) {
                        // те же заметки, но с новым ключом
                        Store.Session updated = new Store.Session(
                                slot, created.salt, created.key, toJson());
                        if (!store.save(updated)) {
                            showError("Не удалось сохранить");
                            return;
                        }
                        session = updated;
                    } else if (!store.save(created)) {
                        showError("Не удалось сохранить");
                        return;
                    }
                    toast("Пароль сохранён");
                    showSettings();
                } catch (Exception e) {
                    showError("Не удалось сохранить");
                }
            });
        });
    }

    private boolean validNewPassword(String password, String repeat) {
        if (password.length() < MIN_PASSWORD) {
            showError("Пароль: минимум " + MIN_PASSWORD + " символа");
            return false;
        }
        if (!password.equals(repeat)) {
            showError("Пароли не совпадают");
            return false;
        }
        return true;
    }

    /** Тяжёлые вычисления в фоне. Результат отбрасывается, если уже была блокировка. */
    private <T> void background(Callable<T> work, Consumer<T> done) {
        if (busy) return;
        busy = true;
        int ticket = generation;
        executor.execute(() -> {
            try {
                T result = work.call();
                runOnUiThread(() -> {
                    if (ticket != generation) return;
                    busy = false;
                    done.accept(result);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (ticket != generation) return;
                    busy = false;
                    showError("Ошибка, попробуйте ещё раз");
                });
            }
        });
    }

    // ---------- Элементы интерфейса ----------

    private void presentDialog(AlertDialog newDialog) {
        dialog = newDialog;
        // У диалога своё окно, запрет скриншотов нужен и ему
        if (dialog.getWindow() != null) {
            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
        dialog.show();
    }

    private void show(View view) {
        root.removeAllViews();
        root.addView(view);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private LinearLayout column() {
        LinearLayout layout = new LinearLayout(ui);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(20), dp(16), dp(20), dp(16));
        return layout;
    }

    private ScrollView scroll(View child) {
        ScrollView view = new ScrollView(ui);
        view.addView(child);
        return view;
    }

    private TextView label(String value) {
        TextView view = new TextView(ui);
        view.setText(value);
        view.setTextSize(look.textSize());
        view.setTextColor(look.textColor());
        view.setPadding(0, dp(8), 0, dp(8));
        return view;
    }

    private TextView heading(String value) {
        TextView view = label(value);
        view.setTextSize(look.textSize() + 8);
        return view;
    }

    private Button button(String value, View.OnClickListener listener) {
        Button view = new Button(ui);
        view.setText(value);
        view.setAllCaps(false);
        view.setTextSize(look.textSize());
        view.setTextColor(0xFFFFFFFF);
        view.setBackgroundTintList(ColorStateList.valueOf(look.accent()));
        view.setOnClickListener(listener);
        return view;
    }

    private EditText field(String hint, int inputType) {
        EditText view = new EditText(ui);
        view.setHint(hint);
        view.setInputType(inputType);
        view.setImeOptions(EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING);
        view.setSaveEnabled(false);
        view.setTextSize(look.textSize());
        view.setTextColor(look.textColor());
        view.setHintTextColor(look.hintColor());
        view.setBackgroundTintList(ColorStateList.valueOf(look.accent()));
        return view;
    }

    private EditText passwordField(String hint) {
        return field(hint, InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_PASSWORD);
    }

    private static String text(EditText view) {
        return view.getText().toString();
    }

    /** Любая ошибка: звук и сообщение. */
    private void showError(String message) {
        playErrorSound();
        toast(message);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}
