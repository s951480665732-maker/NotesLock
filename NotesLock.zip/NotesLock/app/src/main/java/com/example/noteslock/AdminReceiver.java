package com.example.noteslock;

import android.app.admin.DeviceAdminReceiver;

/** Нужен системе, чтобы приложению можно было разрешить блокировку экрана. */
public class AdminReceiver extends DeviceAdminReceiver {
}
