package com.example.noteslock;

import android.content.Context;
import android.content.SharedPreferences;

import java.security.GeneralSecurityException;
import java.util.Base64;

import javax.crypto.AEADBadTagException;
import javax.crypto.SecretKey;

/** Два независимых хранилища (0 и 1): у каждого свой пароль и свои заметки. */
final class Store {
    static final int SLOTS = 2;

    static final class Session {
        final int slot;
        final byte[] salt;
        final SecretKey key;
        final String json;

        Session(int slot, byte[] salt, SecretKey key, String json) {
            this.slot = slot;
            this.salt = salt;
            this.key = key;
            this.json = json;
        }
    }

    private final SharedPreferences prefs;

    Store(Context context) {
        prefs = context.getSharedPreferences("vaults", Context.MODE_PRIVATE);
    }

    boolean exists(int slot) {
        return prefs.contains("data" + slot);
    }

    /** Новое пустое хранилище. На диск пишется только через save(). */
    Session create(int slot, String password) throws GeneralSecurityException {
        byte[] salt = Crypto.newSalt();
        return new Session(slot, salt, Crypto.deriveKey(password, salt), "[]");
    }

    /** Возвращает null, если пароль не подходит к этому хранилищу. */
    Session openSlot(int slot, String password) throws GeneralSecurityException {
        String salt64 = prefs.getString("salt" + slot, null);
        String data = prefs.getString("data" + slot, null);
        if (salt64 == null || data == null) return null;
        byte[] salt = Base64.getDecoder().decode(salt64);
        SecretKey key = Crypto.deriveKey(password, salt);
        try {
            return new Session(slot, salt, key, Crypto.decrypt(data, key));
        } catch (AEADBadTagException wrongPassword) {
            return null;
        }
    }

    Session open(String password) throws GeneralSecurityException {
        for (int slot = 0; slot < SLOTS; slot++) {
            Session session = openSlot(slot, password);
            if (session != null) return session;
        }
        return null;
    }

    boolean save(Session... sessions) throws GeneralSecurityException {
        SharedPreferences.Editor editor = prefs.edit();
        for (Session s : sessions) {
            editor.putString("salt" + s.slot, Base64.getEncoder().encodeToString(s.salt));
            editor.putString("data" + s.slot, Crypto.encrypt(s.json, s.key));
        }
        return editor.commit();
    }

    /** Стирает оба пароля и все заметки. */
    boolean wipe() {
        return prefs.edit().clear().commit();
    }
}
