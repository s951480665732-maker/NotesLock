package com.example.noteslock;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки внешнего вида. Секретов здесь нет, поэтому они не шифруются. */
final class Look {
    static final String THEME = "theme";
    static final String ACCENT = "accent";
    static final String SIZE = "size";
    static final String PREVIEW = "preview";

    static final String[] THEME_NAMES = {"Светлая", "Тёмная", "Чёрная"};
    static final String[] ACCENT_NAMES =
            {"Синий", "Зелёный", "Красный", "Фиолетовый", "Оранжевый", "Серый"};
    private static final int[] ACCENTS =
            {0xFF3F51B5, 0xFF2E7D32, 0xFFC62828, 0xFF6A1B9A, 0xFFBF360C, 0xFF455A64};
    static final String[] SIZE_NAMES = {"Маленький", "Средний", "Большой", "Очень большой"};
    private static final int[] SIZES = {14, 16, 19, 22};

    private final SharedPreferences prefs;

    Look(Context context) {
        prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    int theme() {
        return prefs.getInt(THEME, 0);
    }

    int accentIndex() {
        return prefs.getInt(ACCENT, 0);
    }

    int sizeIndex() {
        return prefs.getInt(SIZE, 1);
    }

    boolean preview() {
        return prefs.getInt(PREVIEW, 1) == 1;
    }

    void set(String name, int value) {
        prefs.edit().putInt(name, value).apply();
    }

    void reset() {
        prefs.edit().clear().apply();
    }

    boolean dark() {
        return theme() != 0;
    }

    int accent() {
        return ACCENTS[accentIndex()];
    }

    int textSize() {
        return SIZES[sizeIndex()];
    }

    int background() {
        return new int[]{0xFFFFFFFF, 0xFF1E1E1E, 0xFF000000}[theme()];
    }

    int card() {
        return new int[]{0xFFEEEEEE, 0xFF333333, 0xFF1A1A1A}[theme()];
    }

    int textColor() {
        return dark() ? 0xFFEEEEEE : 0xFF111111;
    }

    int hintColor() {
        return dark() ? 0xFF999999 : 0xFF666666;
    }
}
