package com.example.noteslock;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Блокировка телефона после нескольких неверных паролей подряд. */
final class PhoneLock {
    static final int MAX_FAILS = 3;

    private final SharedPreferences prefs;
    private final DevicePolicyManager manager;
    private final ComponentName admin;

    PhoneLock(Context context) {
        prefs = context.getSharedPreferences("security", Context.MODE_PRIVATE);
        manager = context.getSystemService(DevicePolicyManager.class);
        admin = new ComponentName(context, AdminReceiver.class);
    }

    boolean hasPermission() {
        return manager != null && manager.isAdminActive(admin);
    }

    /** Включено в настройках и разрешение всё ещё выдано. */
    boolean enabled() {
        return prefs.getBoolean("wanted", false) && hasPermission();
    }

    void setWanted(boolean wanted) {
        prefs.edit().putBoolean("wanted", wanted).putInt("fails", 0).commit();
    }

    /** Системное окно, где пользователь сам даёт разрешение. */
    Intent permissionRequest() {
        return new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Чтобы блокировать экран телефона после " + MAX_FAILS
                                + " неверных паролей в заметках.");
    }

    /** Выключает функцию и отдаёт разрешение обратно (иначе приложение не удалить). */
    void disable() {
        setWanted(false);
        if (hasPermission()) manager.removeActiveAdmin(admin);
    }

    void passwordCorrect() {
        prefs.edit().putInt("fails", 0).commit();
    }

    /**
     * Считает неверный пароль. Возвращает, сколько попыток осталось;
     * 0 — телефон заблокирован. Счётчик хранится на диске и переживает перезапуск.
     */
    int passwordWrong() {
        int fails = prefs.getInt("fails", 0) + 1;
        if (fails < MAX_FAILS) {
            prefs.edit().putInt("fails", fails).commit();
            return MAX_FAILS - fails;
        }
        passwordCorrect(); // после блокировки снова даётся MAX_FAILS попытки
        manager.lockNow();
        return 0;
    }
}
