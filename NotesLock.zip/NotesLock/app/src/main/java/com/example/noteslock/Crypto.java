package com.example.noteslock;

import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/** Шифрование заметок: PBKDF2 + AES-256-GCM. Сам пароль нигде не сохраняется. */
final class Crypto {
    private static final int ITERATIONS = 210_000;
    private static final int IV_LENGTH = 12;

    private Crypto() {}

    static byte[] newSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return salt;
    }

    static SecretKey deriveKey(String password, byte[] salt) throws GeneralSecurityException {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256);
        try {
            byte[] key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(spec).getEncoded();
            return new SecretKeySpec(key, "AES");
        } finally {
            spec.clearPassword();
        }
    }

    static String encrypt(String text, SecretKey key) throws GeneralSecurityException {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] iv = cipher.getIV();
        byte[] data = cipher.doFinal(text.getBytes(StandardCharsets.UTF_8));
        byte[] out = Arrays.copyOf(iv, iv.length + data.length);
        System.arraycopy(data, 0, out, iv.length, data.length);
        return Base64.getEncoder().encodeToString(out);
    }

    /** Бросает AEADBadTagException, если ключ (пароль) неверный. */
    static String decrypt(String encoded, SecretKey key) throws GeneralSecurityException {
        byte[] in = Base64.getDecoder().decode(encoded);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, in, 0, IV_LENGTH));
        byte[] text = cipher.doFinal(in, IV_LENGTH, in.length - IV_LENGTH);
        return new String(text, StandardCharsets.UTF_8);
    }
}
